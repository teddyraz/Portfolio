import React, { useState } from 'react'

const projectsData = [
  { id: 1, category: 'Web Development', title: 'Project A', description: 'Description of Project A.' },
  { id: 2, category: 'UI/UX', title: 'Project B', description: 'Description of Project B.' },
  { id: 3, category: 'Branding', title: 'Project C', description: 'Description of Project C.' }
  // Add more projects as needed
]

function Projects() {
  const [filter, setFilter] = useState('All')

  const filteredProjects = filter === 'All'
    ? projectsData
    : projectsData.filter(project => project.category === filter)

  return (
    <section className="p-8">
      <h2 className="text-3xl font-bold mb-4">Projects</h2>
      <div className="mb-4">
        <button onClick={() => setFilter('All')} className="mr-2 p-2 border">All</button>
        <button onClick={() => setFilter('Web Development')} className="mr-2 p-2 border">Web Development</button>
        <button onClick={() => setFilter('UI/UX')} className="mr-2 p-2 border">UI/UX</button>
        <button onClick={() => setFilter('Branding')} className="mr-2 p-2 border">Branding</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredProjects.map(project => (
          <div key={project.id} className="border p-4">
            <h3 className="font-bold">{project.title}</h3>
            <p>{project.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Projects