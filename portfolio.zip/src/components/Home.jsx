import React from 'react'
import ThreeScene from './ThreeScene'
import { Link } from 'react-router-dom'

function Home() {
  return (
    <section className="relative h-screen flex flex-col justify-center items-center">
      <ThreeScene />
      <div className="absolute z-10 text-center">
        <h2 className="text-4xl font-bold">Welcome to Nero.io Portfolio</h2>
        <p className="mt-4 text-xl">Innovative Solutions in Software Development</p>
        <Link to="/about" className="mt-6 inline-block px-6 py-3 bg-black text-white font-semibold">
          Learn More
        </Link>
      </div>
    </section>
  )
}

export default Home