import React from 'react'

function Footer() {
  return (
    <footer className="bg-black text-white p-4 text-center">
      <p>Unlock Your Brand’s Potential | Digital Marketing & Software Development Agency</p>
    </footer>
  )
}

export default Footer