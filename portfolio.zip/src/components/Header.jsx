import React from 'react'
import { Link } from 'react-router-dom'
import { FaInstagram } from 'react-icons/fa'

function Header() {
  return (
    <header className="flex justify-between items-center p-4 shadow-md">
      <h1 className="text-2xl font-bold">Nero.io</h1>
      <nav className="flex space-x-4">
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/portfolio">Portfolio</Link>
        <Link to="/projects">Projects</Link>
        <Link to="/services">Services</Link>
        <Link to="/contact">Contact</Link>
      </nav>
      <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-2xl">
        <FaInstagram />
      </a>
    </header>
  )
}

export default Header