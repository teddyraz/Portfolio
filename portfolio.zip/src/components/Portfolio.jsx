import React from 'react'

function Portfolio() {
  return (
    <section className="p-8">
      <h2 className="text-3xl font-bold mb-4">Portfolio</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Example portfolio items */}
        <div className="border p-4">
          <h3 className="font-bold">Project One</h3>
          <p>Case study or description goes here.</p>
        </div>
        <div className="border p-4">
          <h3 className="font-bold">Project Two</h3>
          <p>Case study or description goes here.</p>
        </div>
        <div className="border p-4">
          <h3 className="font-bold">Project Three</h3>
          <p>Case study or description goes here.</p>
        </div>
      </div>
    </section>
  )
}

export default Portfolio