import React from 'react'

function About() {
  return (
    <section className="p-8">
      <h2 className="text-3xl font-bold mb-4">About Us</h2>
      <p>
        At Nero.io, we are a cutting-edge software development and digital marketing agency. Our mission is to empower brands with innovative technology solutions and stunning design.
      </p>
    </section>
  )
}

export default About