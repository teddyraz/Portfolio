import React, { useState } from 'react'

function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState('')

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    // For demonstration, simulate an API call
    setStatus('Sending...')
    setTimeout(() => {
      setStatus('Message sent!')
    }, 2000)
  }

  return (
    <section className="p-8">
      <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-4 max-w-md">
        <input type="text" name="name" placeholder="Your Name" className="p-2 border" value={formData.name} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Your Email" className="p-2 border" value={formData.email} onChange={handleChange} required />
        <textarea name="message" placeholder="Your Message" className="p-2 border" value={formData.message} onChange={handleChange} required />
        <button type="submit" className="p-2 bg-black text-white">Send Message</button>
        {status && <p>{status}</p>}
      </form>
    </section>
  )
}

export default Contact